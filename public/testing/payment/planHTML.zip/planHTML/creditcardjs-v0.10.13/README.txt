How to add Creditcard.js to your payment page:

1 Copy and paste creditcardjs-v0.10.13.html into your payment page source html,
  and comment out the old credit card form html.

2 Upload creditcardjs-v0.10.13.min.css and creditcardjs-v0.10.13.min.js to your webserver.

3 In the html, change the css link href and js script src to point to these
  upload locations.

4 Change the name and value attributes (e.g. <input name="change-this-value">)
  to match those in your previous credit card html form. These values are
  submitted to the server, so make sure they match the values from your old credit
  card html.

Feel free to send questions to contact@creditcardjs.com.
